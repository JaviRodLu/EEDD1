#include <iostream>
#include <ctime>
#include "PilasColas.h"
#include <iomanip>
#define N1 100
#define N2 10
#define N3 5
#define FurgonetasNO 20
#define FurgonetasNE 20
#define FurgonetasSO 20
#define FurgonetasSE 20
using namespace std;
string padTo(std::string &str, const size_t num, const char paddingChar = '0')
{
    if(num > str.size())
        str.insert(0, num - str.size(), paddingChar);
    return str;
}

string generarIdPaquete()
{
    string id;
    char abecedario[] = {'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'};
    std::string parte1 = to_string(rand()%99);
    std::string parte2 = to_string(rand()%9999);
    id= padTo(parte1,2)+  abecedario[rand()%26] + padTo(parte2,4);
//    id = padTo(to_string(rand()%99),2) +  abecedario[rand()%26] + padTo(to_string(rand()%9999),4);

    return id;
}

string generarNIF()
{
    int numero;
    string NIF;
    char letras[] = {'T','R','w','A','G','M','Y','F','P','D','X','B','N','J','Z','S','Q','V','H','L','C','K','E'};

    for (int i=0; i<6; i++)
    {
        numero = numero*10 + rand()%10;
    }

    NIF = to_string(numero) + letras[numero%23];

    return NIF;
}

CoordenadasGPS generarCoordenadas()
{
    CoordenadasGPS c;
    int gradLat, minLat, segLat, gradLong, minLong, segLong;

    gradLat = 40;
    minLat = 29 + rand()%3;
    segLat = rand()%60;
    gradLong = -3;
    minLong = 19 + rand()%7;
    segLong = rand()%60;

    c.latitud[0] = gradLat;
    c.latitud[1] = minLat;
    c.latitud[2] = segLat;
    c.longitud[0] = gradLong;
    c.longitud[1] = minLong;
    c.longitud[2] = segLong;

    return c;
}

Paquete generarPaquete()
{
    Paquete p;

    p.idPaquete = generarIdPaquete();
    p.coordenadas = generarCoordenadas();
    p.NIF = generarNIF();

    return p;
}

void cogerPaquetes(int contador)
{
    do
    {
        cout << '\n' << "Presiona Enter para coger m�s paquetes..." << '\n' << endl;
    }
    while (cin.get() != '\n');
    contador++;
}

int main()
{
    cout<<string(33, '#')<<"ALMACEN DE PAQUETES"<<string(33, '#')<<endl;
    cout<<string(27, '=')<<"LISTADO DE PAQUETES ALMACENADOS"<<string(27, '=')<<endl;
    srand(time(NULL));
    /*ListaZonas zonas= new ListaZonas();
    ListaMuelles muelles= new ListaMuelles();*/
    //Cola almacen= new Cola(); //muelleNO, muelleNE, muelleSO, muelleSE, zonaNO, zonaNE, zonaSO, zonaSE;
    Cola almacen;
    Pila muelleNO, muelleNE, muelleSO, muelleSE;
    int paquetesGenerados=0,paquetesCogidos=0, paquetesCogidosNO=0,paquetesCogidosNE=0,paquetesCogidosSO=0,paquetesCogidosSE=0, paquetesCargados=0, contador=0;
    int gradLat=0, minLat=0, segLat=0, gradLong=0, minLong=0, segLong=0;
    Paquete p;
    /*for(int i=0; i<N4;i++)
    {

    }*/
    for (int j=0; j<N1; j++)
    {
        p = generarPaquete();
        almacen.encolar(p);
        ++paquetesGenerados;
        cout <<setw(3)<< j+1 <<". " <<"ID: " <<setw(7)<<p.idPaquete <<" NIF: "<<setw(9)<<p.NIF<<" Coordenadas: Latitud: "<<setw(2)<<p.coordenadas.latitud[0]<<"*"<<setw(2)<<p.coordenadas.latitud[1]<<"'"<<setw(2)<<p.coordenadas.latitud[2]<<"''"<< " Longitud: "<<setw(2)<<p.coordenadas.longitud[0]<<"*"<<setw(2)<<p.coordenadas.longitud[1]<<"'"<<setw(2)<<p.coordenadas.longitud[2]<<"''"<< endl; //Prueba
    }
    //Presionar Enter para coger N2 paquetes de la cola

    while (paquetesCogidos < N2)
    {

        p = almacen.desencolar();
        gradLat = p.coordenadas.latitud[0];
        minLat = p.coordenadas.latitud[1];
        segLat = p.coordenadas.latitud[2];
        gradLong = p.coordenadas.longitud[0];
        minLong = p.coordenadas.longitud[1];
        segLong = p.coordenadas.longitud[2];

        if (((minLat >=29) && (segLat >= 30)) || (minLat >=30))
        {
            //Omitimos los grados porque son siempre los mismos (al menos en esta aplicaci�n)
            if (minLong >= 22)
            {
                muelleNO.apilar(p);
                ++paquetesCogidosNO;
                muelleNO.
                if paquetesCogidosNO<5:

            }
            else
            {
                muelleNE.apilar(p);
                ++paquetesCogidosNE;
            }
        }
        else
        {
            if (minLong >=22)
            {
                muelleSO.apilar(p);
                ++paquetesCogidosSO;

            }
            else
            {
                muelleSE.apilar(p);
                ++paquetesCogidosSE;
            }
        }

        ++paquetesCogidos;
        //while (paquetesCargados < N3)
    }
    muelleNO.recorrer();

    //cogerPaquetes(contador);

    return 0;
}
