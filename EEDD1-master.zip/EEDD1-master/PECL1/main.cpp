#include <iostream>
#include <ctime>
#include "PilasColas.h"
#include <iomanip>
#include <vector>
#define N1 100
#define N2 10
#define N3 5
#define CamionesNO 20
#define CamionesNE 20
#define CamionesSO 20
#define CamionesSE 20
using namespace std;
string padTo(std::string &str, const size_t num, const char paddingChar = '0')//Funcion que sirve para rellenar con 0 cuando la division de los numeros aleatorios generados para el id entre 99 y 9999 sale de menos numeros
{
    if(num > str.size())
        str.insert(0, num - str.size(), paddingChar);
    return str;
}

string generarIdPaquete()//Funcion que genera el ID del paquete
{
    string id;
    char abecedario[] = {'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'};
    std::string parte1 = to_string(rand()%99);
    std::string parte2 = to_string(rand()%9999);
    id= padTo(parte1,2)+  abecedario[rand()%26] + padTo(parte2,4);

    return id;
}

string generarNIF()//Funcion que genera el NIF del paquete
{
    int numero;
    string NIF;
    char letras[] = {'T','R','w','A','G','M','Y','F','P','D','X','B','N','J','Z','S','Q','V','H','L','C','K','E'};

    for (int i=0; i<6; i++)
    {
        numero = numero*10 + rand()%10;
    }

    NIF = to_string(numero) + letras[numero%23];

    return NIF;
}

CoordenadasGPS generarCoordenadas()//Funcion que genera las coordenadas del paquete
{
    CoordenadasGPS c;
    int gradLat, minLat, segLat, gradLong, minLong, segLong;

    gradLat = 40;
    minLat = 29 + rand()%3;
    segLat = rand()%60;
    gradLong = -3;
    minLong = 19 + rand()%7;
    segLong = rand()%60;

    c.latitud[0] = gradLat;
    c.latitud[1] = minLat;
    c.latitud[2] = segLat;
    c.longitud[0] = gradLong;
    c.longitud[1] = minLong;
    c.longitud[2] = segLong;

    return c;
}

Paquete generarPaquete()//Funcion que genera un paquete
{
    Paquete p;

    p.idPaquete = generarIdPaquete();
    p.coordenadas = generarCoordenadas();
    p.NIF = generarNIF();

    return p;
}

void sigInstruccion(int c)//M�todo para ir paso a paso con la ejecuci�n del programa
{
    cout << '\n' << "Presiona Enter para realizar la siguiente instruccion..." << '\n' << endl;
    getchar();
    c++;
}

int main()
{
    cout<<string(33, '#')<<"ALMACEN DE PAQUETES"<<string(33, '#')<<endl;
    cout<<string(27, '=')<<"LISTADO DE PAQUETES ALMACENADOS"<<string(27, '=')<<endl;
    srand(time(NULL));
    Cola almacen;
    Pila muelleNO, muelleNE, muelleSO, muelleSE,camionesNO,camionesNE,camionesSO,camionesSE;
    int paquetesGenerados=0,paquetesCogidos=0, paquetesCogidosNO=0,paquetesCogidosNE=0,paquetesCogidosSO=0,paquetesCogidosSE=0, paquetesCargadosNO=0,paquetesCargadosNE=0,paquetesCargadosSO=0,paquetesCargadosSE=0, contador=0;
    int gradLat=0, minLat=0, segLat=0, gradLong=0, minLong=0, segLong=0;
    Paquete p,qNO,qNE,qSO,qSE;
    int flag,veces_enter=0;
    int n;
    int c=0;
    sigInstruccion(c);
    for (int j=0; j<N1; j++)//Crea los 100 paquetes y los muestra por pantalla
    {
        p = generarPaquete();
        almacen.encolar(p);
        ++paquetesGenerados;
        n=j+1;
        cout <<setw(3)<< n <<". " <<"ID: " <<setw(7)<<p.idPaquete <<" NIF: "<<setw(9)<<p.NIF<<" Coordenadas: Latitud: "<<setw(2)<<p.coordenadas.latitud[0]<<"*"<<setw(2)<<p.coordenadas.latitud[1]<<"'"<<setw(2)<<p.coordenadas.latitud[2]<<"''"<< " Longitud: "<<setw(2)<<p.coordenadas.longitud[0]<<"*"<<setw(2)<<p.coordenadas.longitud[1]<<"'"<<setw(2)<<p.coordenadas.longitud[2]<<"''"<< endl; //Prueba
    }
    //Presionar Enter para coger N2 paquetes de la cola y las variables paquetesCogidos y paquetes Cargados se metan en una variable y se borren
    sigInstruccion(c);
    while (paquetesCogidos < N2)
    {

        p = almacen.desencolar();
        gradLat = p.coordenadas.latitud[0];
        minLat = p.coordenadas.latitud[1];
        segLat = p.coordenadas.latitud[2];
        gradLong = p.coordenadas.longitud[0];
        minLong = p.coordenadas.longitud[1];
        segLong = p.coordenadas.longitud[2];

        if (((minLat >=29) && (segLat >= 30)) || (minLat >=30))//Envio de los paquetes a cada muelle seg�n la direccion
        {
            //Omitimos los grados porque son siempre los mismos (al menos en esta aplicaci�n)
            if (minLong >= 22)
            {
                muelleNO.apilar(p);
                ++paquetesCogidosNO;


            }
            else
            {
                muelleNE.apilar(p);
                ++paquetesCogidosNE;
            }
        }
        else
        {
            if (minLong >=22)
            {
                muelleSO.apilar(p);
                ++paquetesCogidosSO;

            }
            else
            {
                muelleSE.apilar(p);
                ++paquetesCogidosSE;
            }
        }

        ++paquetesCogidos;

    }
    /*while (paquetesCogidosNO<=5){

        cout<<"camionesNO"<<endl;
        qNO=muelleNO.desapilar();
        camionesNO.apilar(qNO);
        ++paquetesCogidosNO
        ++paquetesCargadosNO
    }
    /*if (paquetesCogidosNO < N3){

        cout<<"camionesNO"<<endl;
        qNO=muelleNO.desapilar();
        camionesNO.apilar(qNO);
    }

    else{
            cout<<"Hola"<<endl;
    }

    /*cami=;

    qNE=muelleNE.desapilar();

    qSE=muelleSE.desapilar();

    qSO=muelleSO.desapilar();
    if (sizeOf(qNO)<5):
        camionesNO.apilar(qNO);
    else:
        pass
    cout<<"camiones"<<endl;
    camionesNO.desapilar();

    //cogerPaquetes(contador);*/

    return 0;
}
